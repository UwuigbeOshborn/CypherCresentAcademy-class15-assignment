﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass15
{
    public class DivideByZeroExceptionHandling
    {
        //Constructors
        public DivideByZeroExceptionHandling()
        {

        }
        public DivideByZeroExceptionHandling(int firstValue, int secondValue)
        {
            FirstValue = firstValue;    
            SecondValue = secondValue;  
        }
        //Methods
        public void Divider() 
        {
            try
            {
                Console.WriteLine($"The result is {FirstValue / SecondValue}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Undefied result, as {FirstValue} can not be divided by {SecondValue}");
                Console.WriteLine(ex.Message);
            }
        }
        //Properties
        public int FirstValue { get; set; }
        public int SecondValue { get; set; }
    }
}
