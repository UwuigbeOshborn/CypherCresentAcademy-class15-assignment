﻿// See https://aka.ms/new-console-template for more information
using CypherCresentClass15;

// Implementing the Index Out Of Range Exception
Console.WriteLine("\n --------------------   Implementing the Index Out Of Range Exception   -----------1----------");
var MyArray = new IndexOutOfRangeExceptionHandling(1, 3, 3, 4, 2, 6, 4, 8);
MyArray.CheckIndex();


// Implementing the Divide By Zero Exception
Console.WriteLine("\n --------------------   Implementing the Divide By Zero Exception   ----------2-----------");
int valve1, valve2;
Console.WriteLine("\nEnter first valve: ");
valve1 = int.Parse(Console.ReadLine());
Console.WriteLine("\nEnter second valve: ");
valve2 = int.Parse(Console.ReadLine());
var MyDivision = new DivideByZeroExceptionHandling(valve1, valve2);
MyDivision.Divider();


// Implementing the Format Exception 
Console.WriteLine("\n --------------------   Implementing the Format Exception   -----------3----------");
var MyFormatting = new FormatExceptionHandling("12f338");
MyFormatting.CastVariable();


// Implementing the Invalid Cast Exception 
Console.WriteLine("\n --------------------   Implementing the Invalid Cast Exception    ----------4-----------");
var MyCasting = new InvalidCastExceptionHandling(true);
MyCasting.CastVariable();


// Implementing the Null Reference Exception
Console.WriteLine("\n --------------------   Implementing the Null Reference Exception   -----------5----------");
var Faith = new NullReferenceExceptionHandling("Faith", "Murphy");
Faith.ReferenceMethod(Faith);
var Oshborn = new NullReferenceExceptionHandling("Oshborn");
Oshborn.ReferenceMethod(Oshborn);

// Implementing the Array Type Mismatch Exception
Console.WriteLine("\n --------------------   Implementing the Array Type Mismatch Exception    ----------6-----------");
var MyArray2= new ArrayTypeMismatchExceptionHandling("Sarah", "David", "Jaja", "Iruoma");
MyArray2.ArrayTypeMethod();


// Implementing the Stack Over Flow Exception 
Console.WriteLine("\n --------------------   Implementing the Stack Over Flow Exception    -----------7----------");
var Stack = new StackOverFlowExceptionHandling();
try
{
    //The ex method is called by passing zero as a parameter to start the infinite recursion
    Stack.StackMethod(0);
}
catch (StackOverflowException ex)
{
    Console.WriteLine(ex.Message);
}