﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass15
{
    public class ArrayTypeMismatchExceptionHandling
    {
        //Constructors
        public ArrayTypeMismatchExceptionHandling(params string[] name)
        {
            Name = name;
        }
        //Methods
        public void ArrayTypeMethod()
        {
            Object[] objectarray = (Object[]) Name;
            objectarray[3] = "John";
            try
            {
                Console.WriteLine($"Store element at index 2 {objectarray[2] = 5}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unable to store element of such type in the array ");
                Console.WriteLine(ex.Message);
            }
        }
        //Properties
        public string[] Name { get; set; }
    }
}
