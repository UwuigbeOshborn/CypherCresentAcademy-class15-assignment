﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass15
{
    public class NullReferenceExceptionHandling
    {
        //Constructors
        public NullReferenceExceptionHandling()
        {

        }
        public NullReferenceExceptionHandling(string firstName)
        {
            FirstName = firstName;

        }
        public NullReferenceExceptionHandling(string firstName, string lastName)
        {
            FirstName = firstName;

            LastName = lastName;
        }
        //Methods
        public void ReferenceMethod(NullReferenceExceptionHandling Reference)
        {
            try
            {
                Console.WriteLine($"My first name is {Reference.FirstName} it has {Reference.FirstName.Length} letters");
                Console.WriteLine($"My last name is {Reference.LastName} it has {Reference.LastName.Length} letters\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Please enter your first name and last name");
                Console.WriteLine(ex.Message);
            }
        }
        //Properties
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
