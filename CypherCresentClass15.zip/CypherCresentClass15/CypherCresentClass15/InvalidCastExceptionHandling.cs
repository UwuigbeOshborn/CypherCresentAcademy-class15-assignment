﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass15
{
    public class InvalidCastExceptionHandling
    { 
        //Constructors
        public InvalidCastExceptionHandling()
        {

        }
        public InvalidCastExceptionHandling(bool input)
        {

            Input = input;
        }
        //Methods
        public void CastVariable()
        {
            try
            {
                char output = Convert.ToChar(Input);
                Console.WriteLine($"\nCasting string to {output} ");
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nCan not Convert this string to integer");
                Console.WriteLine(ex.Message);
            }
        }
        //Properties

        public bool Input { get; set; }
    }
}
