﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass15
{
    public class StackOverFlowExceptionHandling
    {
        //Constructors
        public StackOverFlowExceptionHandling()
        {

        }
        public StackOverFlowExceptionHandling(int firstValue, int secondValue)
        {
            FirstValue = firstValue;
            SecondValue = secondValue;
        }
        //Methods
        public void StackMethod(int number)
        {
            Console.WriteLine(number);
            StackMethod(++number);
        }
        
        //Properties
        public int FirstValue { get; set; }
        public int SecondValue { get; set; }
    }
}

