﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass15
{
    public class IndexOutOfRangeExceptionHandling
    {
        //Constructors
        public IndexOutOfRangeExceptionHandling()
        {

        }
        public IndexOutOfRangeExceptionHandling(params int[] input)
        {
            Input = input;
        }
        //Methods
        public void CheckIndex()
        {
            var arrayInput = this.Input;
            for (int i = -1; i < arrayInput.Length; i++)
            {
                try
                {
                    Console.WriteLine(arrayInput[i + 1]);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("you have come to the end of the array");
                    Console.WriteLine(ex.Message);
                }
            }
        }

        //Properties
        public int[] Input { get; set; }
    }
}
