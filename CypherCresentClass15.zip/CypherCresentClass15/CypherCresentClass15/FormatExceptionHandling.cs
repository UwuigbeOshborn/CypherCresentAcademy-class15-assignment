﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass15
{
    public class FormatExceptionHandling
    {
        //Constructors
        public FormatExceptionHandling()
        {

        }
        public FormatExceptionHandling(string input)
        {

            Input = input;
        }
        //Methods
        public void CastVariable() 
        {
            try
            {
                int output = Convert.ToInt32(Input);
                Console.WriteLine($"\nCasting string to {output} ");
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nCan not Convert this string to integer");
                Console.WriteLine(ex.Message);
            }
        }
        //Properties

        public string Input { get; set; }
    }
}
